//package com.example.shoppingmall.home.adapter;
//
//import android.content.Context;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.ImageView;
//
//import androidx.annotation.NonNull;
//import androidx.recyclerview.widget.RecyclerView;
//
//import com.bumptech.glide.Glide;
//import com.example.shoppingmall.R;
//import com.example.shoppingmall.home.bean.ResultBeanData;
//import com.example.shoppingmall.utils.Constants;
//import com.youth.banner.Banner;
//import com.youth.banner.loader.ImageLoaderInterface;
//
//import java.util.ArrayList;
//import java.util.List;
//
//public class DemoFragmentAdapter extends RecyclerView.Adapter{
//    /**
//     * 初始化布局
//     */
//    private final LayoutInflater mLayoutInflater;
//    /**
//     * 当前数据类型
//     */
//    public int currentType = 0;
//    /**
//     * 广告条幅类型
//     */
//    public static final int BANNER = 0;
//    /**
//     * 频道类型
//     */
//    public static final int CHANNEL = 1;
//    /**
//     * 活动类型
//     */
//    public static final int ACT = 2;
//    /**
//     * 秒杀类型
//     */
//    public static final int SECKILL = 3;
//    /**
//     * 推荐类型
//     */
//    public static final int RECOMMEND = 5;
//    /**
//     * 热卖类型
//     */
//    public static final int HOT = 6;
//    private ResultBeanData.ResultBean resultBean;
//    private Context mContext;
//
//    public DemoFragmentAdapter( ResultBeanData.ResultBean resultBean, Context mContext) {
//        this.resultBean = resultBean;
//        this.mContext = mContext;
//        mLayoutInflater=LayoutInflater.from(mContext);
//    }
//
//
//
//    @NonNull
//    @Override
//    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//       View view=mLayoutInflater.inflate(R.layout.banner_viewpager,null,false);
//        BannersViewHolder bannersViewHolder=new BannersViewHolder(mContext,view,resultBean);
//        return bannersViewHolder;
//    }
//
////    @Override
////    public int getItemViewType(int position) {
////        switch (position){
////            case BANNER:
////                currentType=BANNER;
////                break;
////            case CHANNEL:
////                currentType = CHANNEL;
////                break;
////            case ACT:
////                currentType = ACT;
////                break;
////            case SECKILL:
////                currentType = SECKILL;
////                break;
////            case RECOMMEND:
////                currentType = RECOMMEND;
////                break;
////            case HOT:
////                currentType = HOT;
////                break;
////        }
////        return currentType;
////    }
//
//    @Override
//    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
//      if (getItemViewType(position)==BANNER){
//          BannersViewHolder bannersViewHolder=(BannersViewHolder)holder;
//          bannersViewHolder.setData(resultBean.getBanner_info());//获得广告轮播的数据
//
//      }
//    }
//
//    @Override
//    public int getItemCount() {
//        return 6;
//    }
//
//    private class BannersViewHolder extends  RecyclerView.ViewHolder {
//        private Context mContext;
//        Banner banner;
//        public BannersViewHolder(Context mContext, @NonNull View itemView, ResultBeanData.ResultBean resultBean) {
//            super(itemView);
//            banner=itemView.findViewById(R.id.banner);
//        }
//
//        public void setData(List<ResultBeanData.ResultBean.BannerInfoBean> banner_info) {
//            List<String> imageUris = new ArrayList<>();
//            for (int i = 0; i < resultBean.getBanner_info().size(); i++) {
//                imageUris.add(resultBean.getBanner_info().get(i).getImage());
//            }
//            //设置图片加载器
//            banner.setImageLoader(new GlideImageLoader());
//        }
//    }
//
//    private class GlideImageLoader implements ImageLoaderInterface {
//        @Override
//        public void displayImage(Context context, Object path, View imageView) {
//            Glide.with(mContext).load(Constants.BASE_URL_IMAGE+path).into((ImageView) imageView);
//        }
//
//        @Override
//        public View createImageView(Context context) {
//            return null;
//        }
//    }
//}

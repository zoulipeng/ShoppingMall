package com.example.shoppingmall.home.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.shoppingmall.R;
import com.example.shoppingmall.home.bean.ResultBeanData;
import com.example.shoppingmall.utils.Constants;
import com.youth.banner.Banner;
import com.youth.banner.listener.OnLoadImageListener;

import java.util.ArrayList;
import java.util.List;

public class HomeFragmentAdapter extends RecyclerView.Adapter  {

    /**
     * 当前数据类型
     */
    public int currentType = 0;
    /**
     * 广告条幅类型
     */
    public static final int BANNER = 0;
    /**
     * 频道类型
     */
    public static final int CHANNEL = 1;
    /**
     * 活动类型
     */
    public static final int ACT = 2;
    /**
     * 秒杀类型
     */
    public static final int SECKILL = 3;
    /**
     * 推荐类型
     */
    public static final int RECOMMEND = 4;
    /**
     * 热卖类型
     */
    public static final int HOT = 5;
    private final Context mContext;
    /**
     * 初始化布局
     */
    private final LayoutInflater mLayoutInflater;
    private final ResultBeanData.ResultBean resultBean;


    public HomeFragmentAdapter(Context mContext, ResultBeanData.ResultBean resultBean) {
        this.mContext = mContext;
        this.resultBean = resultBean;
        mLayoutInflater = LayoutInflater.from(mContext);
    }

    /**
     * 相当于getView 创建ViewHolder部分
     * 创建ViewHolder
     *
     * @param parent
     * @param viewType 当前的类型
     * @return
     */
    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == BANNER) {
            return new BannerViewHolder(mContext, mLayoutInflater.inflate(R.layout.banner_viewpager, null));
        }
        if (viewType == CHANNEL) {
            return new BannerViewHolder(mContext, mLayoutInflater.inflate(R.layout.banner_viewpager, null));
        }
        if (viewType == ACT) {
            return new BannerViewHolder(mContext, mLayoutInflater.inflate(R.layout.banner_viewpager, null));
        }
        if (viewType == SECKILL) {
            return new BannerViewHolder(mContext, mLayoutInflater.inflate(R.layout.banner_viewpager, null));
        }
        if (viewType == RECOMMEND) {
            return new BannerViewHolder(mContext, mLayoutInflater.inflate(R.layout.banner_viewpager, null));
        }
        if (viewType == HOT) {
            return new BannerViewHolder(mContext, mLayoutInflater.inflate(R.layout.banner_viewpager, null));
        }
        return null;
    }

    private class BannerViewHolder extends RecyclerView.ViewHolder {
        private Context mContext;
        private Banner banner;
//        public ResultBeanData.ResultBean resultBean;

        public BannerViewHolder(Context mContext, View itemView) {
            super(itemView);
            this.mContext = mContext;
            this.banner = (Banner) itemView.findViewById(R.id.banner);
//            banner=itemView.findViewById(R.id.banner);


        }


        public void setData(List<ResultBeanData.ResultBean.BannerInfoBean> banner_info) {
            //设置Banner的数据
//            List<String> imagesUrl = new ArrayList<>();
//            for (int i = 0; i < banner_info.size(); i++) {
//                String imageUrl = banner_info.get(i).getImage();
//                imagesUrl.add(imageUrl);
//            }
//-------------------------参考代码---------------------------------------------------------------
            try {
                List<String> imageUris = new ArrayList<>();
                for (int i = 0; i < resultBean.getBanner_info().size(); i++) {
                    imageUris.add(resultBean.getBanner_info().get(i).getImage());
                }
                //设置图片加载器
//            banner.setImageLoader(new MyLoader);
//              banner.setImageLoader(new MyLoader());
//              banner.start();
                banner.setImages(imageUris, new OnLoadImageListener() {
                    @Override
                    public void OnLoadImage(ImageView view, Object url) {
                        Glide.with(mContext).load(Constants.BASE_URL_IMAGE+url).into(view);
                    }
                });
            }catch (Exception e){

            }


        }
    }

    /**
     * 相当于getView中的绑定数据模块
     *
     * @param holder
     * @param position
     */
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (getItemViewType(position)==BANNER){
            BannerViewHolder bannerViewHolder=(BannerViewHolder) holder;
            bannerViewHolder.setData(resultBean.getBanner_info());//获得广告轮播的数据
        }
    }

    /**
     * 得到的类型
     *
     * @param position
     * @return
     */
    @Override
    public int getItemViewType(int position) {
        switch (position) {
            case BANNER:
                currentType = BANNER;
                break;
            case CHANNEL:
                currentType = CHANNEL;
                break;
            case ACT:
                currentType = ACT;
                break;
            case SECKILL:
                currentType = SECKILL;
                break;
            case RECOMMEND:
                currentType = RECOMMEND;
                break;
            case HOT:
                currentType = HOT;
                break;

        }
        return currentType;
    }



    /**
     * 总共有多少个item
     *
     * @return
     */
    @Override
    public int getItemCount() {
        return 6;
    }

//    private class MyLoader extends ImageLoader {
//
//        @Override
//        public void displayImage(Context context, Object path, ImageView imageView) {
//            Glide.with(mContext).load(Constants.BASE_URL_IMAGE+path).into(imageView);
//        }

}
